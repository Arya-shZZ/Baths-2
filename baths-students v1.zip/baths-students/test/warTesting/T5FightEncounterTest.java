package warTesting;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import wars.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Tests related to the fightEncounter method and its outcomes.
 * @author aam (Original author), Dinojan Baskaran (Additions)
 */
public class T5FightEncounterTest {
    BATHS game;

    public T5FightEncounterTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
        // Create a fresh game instance before each test method
        game = new SeaBattles("Jean");
    }

    @After
    public void tearDown() {
    }

    // --- Tests for ManOWar facing Encounters ---

    @Test
    // ManOWar (Belerophon, Str 8) vs Blockade (Enc 3, Req 3) -> Win
    public void manOWarFacingBlockadeWins() {
        game.commissionShip("Belerophon");
        String actual = game.fightEncounter(3);
        assertTrue("ManOWar should win Blockade when strength is sufficient", actual.contains("won"));
    }

    @Test
    // ManOWar (Belerophon, Fee 500) vs Blockade (Enc 3, Prize 150) -> Win Money Check
    public void manOWarFacingBlockadeWinsMoney() {
        double expected = 1000 - 500 + 150; // 650
        game.commissionShip("Belerophon"); // warchest= 500
        game.fightEncounter(3);
        double actual = game.getWarChest();
        assertEquals("War chest incorrect after ManOWar wins Blockade", expected, actual, 0.5);
    }

    @Test
    // ManOWar (Victory, Str 3) vs Blockade (Enc 3, Req 3) -> Win (Equal Strength)
    public void manOWarFacingBlockadeEqualSkillsWins() {
        game.commissionShip("Victory");
        String actual = game.fightEncounter(3);
        assertTrue("ManOWar should win Blockade on equal strength", actual.contains("won"));
    }

    @Test
    // ManOWar (Victory, Fee 500) vs Blockade (Enc 3, Prize 150) -> Win Money Check (Equal Strength)
    public void manOWarFacingBlockadequalSkillsWinsMoney() {
        double expected = 1000 - 500 + 150; // 650
        game.commissionShip("Victory"); // warchest= 500
        game.fightEncounter(3);
        double actual = game.getWarChest();
        assertEquals("War chest incorrect after ManOWar wins Blockade on equal strength", expected, actual, 0.5);
    }

    @Test
    // ManOWar (Victory, Str 3) vs Blockade (Enc 5, Req 7) -> Lose
    public void manOWarFacingBlockadeLosesOnSkill() {
        game.commissionShip("Victory");
        String actual = game.fightEncounter(5);
        assertTrue("ManOWar should lose Blockade when strength is insufficient", actual.contains("lost on battle skill"));
    }


    @Test
    // ManOWar (Victory, Fee 500) vs Blockade (Enc 5, Prize 90) -> Lose Money Check
    public void manOWarFacingBlockadeLostOnSkillLosesMoney() {
        double expected = 1000 - 500 - 90; // 410
        game.commissionShip("Victory"); // warchest= 500
        game.fightEncounter(5); // loses
        double actual = game.getWarChest();
        assertEquals("War chest incorrect after ManOWar loses Blockade", expected, actual, 0.5);
    }


    @Test
    // ManOWar (Endeavour, Str 4) vs Blockade (Enc 5, Req 7) -> Lose, Check Sunk List
    public void manOWarFacingBlockadeonSunkList() {
        game.commissionShip("Endeavour"); // Fee 300, Chest 700
        game.fightEncounter(5); // Lose, Prize 90, Chest 610
        String actual= game.getSunkShips();
        assertTrue("Sunk list should contain Endeavour after losing", actual.contains("Endeavour"));
    }


    @Test
    // ManOWar (Endeavour, Str 4) vs Blockade (Enc 3, Req 3) -> Win Money Check
    public void manOWar2deckFacingBlockadeWinsMoney() {
        double expected = 1000 - 300 + 150; // 850
        game.commissionShip("Endeavour"); // Fee 300, Chest 700
        game.fightEncounter(3); // Win, Prize 150
        double actual = game.getWarChest();
        assertEquals("War chest incorrect after Endeavour wins Blockade", expected, actual, 0.5);
    }

    // --- ManOwar facing Battle ---
    @Test
    // ManOWar (Victory, Str 3) vs Battle (Enc 10, Req 1) -> Win
    public void manOWarFacingBattleWins() {
        game.commissionShip("Victory");
        String actual = game.fightEncounter(10);
        assertTrue("ManOWar should win Battle when strength is sufficient", actual.contains("won"));
    }


    @Test
    // ManOWar (Victory, Fee 500) vs Battle (Enc 10, Prize 250) -> Win Money Check
    public void manOWarFacingBattleWinsMoney() {
        double expected = 1000 - 500 + 250; // 750
        game.commissionShip("Victory"); // warchest= 500
        game.fightEncounter(10);
        double actual = game.getWarChest();
        assertEquals("War chest incorrect after ManOWar wins Battle", expected, actual, 0.5);
    }

    @Test
    // Check if ship is resting (not in squadron) after winning a battle
    public void manOWarFacingBattleRestingNotInSquadron() {
        game.commissionShip("Victory");
        game.fightEncounter(10);  // wins and rests
        assertFalse("Ship should not be in squadron after winning battle (resting)", game.isInSquadron("Victory"));
    }

    @Test
    // Check if a resting ship can be restored to the squadron
    public void manOWarFacingBattleRestingRestoredSquadron() {
        game.commissionShip("Victory");
        game.fightEncounter(10);  // wins and rests
        game.restoreShip("Victory"); // Restore it
        assertTrue("Ship should be back in squadron after being restored", game.isInSquadron("Victory"));
    }

    @Test // Added @Test annotation to make this runnable
    // Check restoring a ship that isn't resting/commissioned does nothing
    public void manOWarRestoredWhenNotInSquadron() {
        //Victory not commissioned, so not in squadron or resting
        game.restoreShip("Victory");
        assertFalse("Restoring a ship not in squadron/resting should have no effect", game.isInSquadron("Victory"));
    }


    @Test
    // ManOWar (Victory, Str 3) vs Battle (Enc 1, Req 3) -> Win (Equal Strength)
    public void manOWarFacingBattleEqualSkillsWins() {
        game.commissionShip("Victory");
        String actual = game.fightEncounter(1);
        assertTrue("ManOWar should win Battle on equal strength", actual.contains("won"));
    }

    @Test
    // ManOWar (Victory, Fee 500) vs Battle (Enc 1, Prize 300) -> Win Money Check (Equal Strength)
    public void manOWarFacingBattleequalSkillsWinsMoney() {
        double expected = 1000 - 500 + 300; // 800
        game.commissionShip("Victory"); // warchest= 500
        game.fightEncounter(1);
        double actual = game.getWarChest();
        assertEquals("War chest incorrect after ManOWar wins Battle on equal strength", expected, actual, 0.5);
    }


    @Test
    // ManOWar (Victory, Str 3) vs Battle (Enc 4, Req 9) -> Lose
    public void manOWarFacingBattleLosesOnSkill() {
        game.commissionShip("Victory");
        String actual = game.fightEncounter(4);
        assertTrue("ManOWar should lose Battle when strength is insufficient", actual.contains("lost on battle skill"));
    }



    @Test
    // ManOWar (Victory, Fee 500) vs Battle (Enc 4, Prize 200) -> Lose Money Check
    public void manOWarFacingBattleLostSkillLosesMoney() {
        double expected = 1000 - 500 - 200; // 300
        game.commissionShip("Victory"); // warchest= 500
        game.fightEncounter(4);
        double actual = game.getWarChest();
        assertEquals("War chest incorrect after ManOWar loses Battle", expected, actual, 0.5);
    }

    @Test
    // Check if ship is on sunk list after losing battle
    public void manOWarFacingBattleisSunk() {
        game.commissionShip("Victory"); // warchest= 500
        game.fightEncounter(4); // Lose, Prize 200, Chest 300
        String actual = game.getSunkShips();
        assertTrue("Sunk list should contain Victory after losing battle", actual.contains("Victory"));
    }

    @Test
    // Check that a sunk ship cannot be restored
    public void manOWarFacingBattleisSunkNotRestored() {
        game.commissionShip("Victory"); // warchest= 500
        game.fightEncounter(4); // Sinks ship
        game.restoreShip("Victory"); // Attempt restore
        assertFalse("Sunk ship should not be in squadron after restore attempt", game.isInSquadron("Victory"));
    }

    // --- ManOWar facing Skirmish (Incompatible) ---
    @Test
    // ManOWar (Belerophon, Str 8) vs Skirmish (Enc 2, Req 3) -> Should be "no ship available"
    public void manOWarFacingSkirmishCantWin() {
        game.commissionShip("Belerophon"); // warchest= 500
        String actual = game.fightEncounter(2); // ManOWar cannot do Skirmish
        assertTrue("Result should indicate no ship available for ManOWar vs Skirmish", actual.contains("no ship available"));
    }

    @Test
    // ManOWar (Belerophon, Fee 500) vs Skirmish (Enc 2, Prize 120) -> Lose Money Check
    public void manOWarFacingSkirmishCantWinMoney() {
        double expected = 1000 - 500 - 120; // 380
        game.commissionShip("Belerophon"); // warchest= 500
        game.fightEncounter(2); // can't do, lose prize
        double actual = game.getWarChest();
        assertEquals("War chest incorrect after ManOWar fails Skirmish", expected, actual, 0.5);
    }


    // --- Invalid Encounter ---
    @Test
    // Check fighting a non-existent encounter number
    public void manOWarFacingNoSuchEncounter() {
        game.commissionShip("Victory");
        String actual = game.fightEncounter(20); // Encounter 20 does not exist
        assertTrue("Result should indicate no such encounter", actual.contains("No such"));
    }

    @Test
    // Check war chest is unchanged when fighting non-existent encounter
    public void manOWarFacingNoSuchEncounterNoDeduction() {
        game.commissionShip("Victory"); // war chest 500
        game.fightEncounter(20); // Invalid encounter
        double expected = 500;
        double actual = game.getWarChest();
        assertEquals("War chest should be unchanged for invalid encounter", expected, actual, 0.5);
    }


    // --- Frigate facing Encounters ---
    @Test
    // Frigate (Sophie, Str 8, has pinnace) vs Blockade (Enc 3, Req 3) -> Win
    public void FrigateFacingBlockadewithPinaceWins() {
       game.commissionShip("Sophie"); // Has pinnace/doctor = true
       String actual = game.fightEncounter(3);
       assertTrue("Frigate with pinnace should win Blockade", actual.contains("won"));
    }

    @Test
    // Frigate (Sophie, Fee 160) vs Blockade (Enc 3, Prize 150) -> Win Money Check
    public void FrigateFacingBlockadewithPinaceWinsMoney() {
       game.commissionShip("Sophie");// war chest 1000 - 160 = 840
       game.fightEncounter(3); // Win, Prize 150. Chest = 840 + 150 = 990
       double actual = game.getWarChest();
       assertEquals("War chest incorrect after Frigate/Pinnace wins Blockade", 990, actual, 0.5);
    }

    @Test
    // Frigate (Surprise, Str 6, no pinnace) vs Blockade (Enc 3, Req 3) -> Lose (No ship available)
    public void FrigateFacingBlockadeNoPinaceloses() {
       game.commissionShip("Surprise"); // hasDoctorOrPinnace = false
       String actual = game.fightEncounter(3); // Frigate cannot do Blockade without pinnace
       assertTrue("Result should indicate no ship available for Frigate vs Blockade without pinnace", actual.contains("no ship"));
    }

    @Test
    // Frigate (Jupiter, Fee 200, no pinnace) vs Blockade (Enc 3, Prize 150) -> Lose Money Check
    public void FrigateFacingBlockadeNoPinacelosesMoney() {
       game.commissionShip("Jupiter"); // warchest 1000 - 200 = 800. hasDoctorOrPinnace = false
       game.fightEncounter(3); // Cannot fight, lose prize. Chest = 800 - 150 = 650
       double actual = game.getWarChest();
       assertEquals("War chest incorrect after Frigate/No Pinnace fails Blockade", 650, actual, 0.5);
    }

   @Test
   // Frigate (Sophie, Str 8) vs Battle (Enc 1, Req 3) -> Win Money Check
    public void FridateFacingBattleWinsMoneyAdded() {
        double expected = 1000 - 160 + 300;  // 1140 -> Error in original test comment? 1000-160=840. 840+300=1140
        game.commissionShip("Sophie"); // Chest 840
        game.fightEncounter(1); // Win, Prize 300
        double actual = game.getWarChest();
        assertEquals("War chest incorrect after Frigate wins Battle", expected, actual, 0.5);
    }

    @Test
    // Frigate (Sophie, Str 8) vs Battle (Enc 4, Req 9) -> Lose Money Check
    public void FridateFacingBattleLosesMoneyDeducted() {
        double expected = 1000 - 160 - 200;  // 640 -> Error in original test comment? 1000-160=840. 840-200=640
        game.commissionShip("Sophie"); // Chest 840
        game.fightEncounter(4); // Lose, Prize 200
        double actual = game.getWarChest();
        assertEquals("War chest incorrect after Frigate loses Battle", expected, actual, 0.5);
    }

    @Test
    // Frigate (Sophie, Str 8) vs Skirmish (Enc 2, Req 3) -> Win Money Check
    public void FridateFacingSkirmishWinsMoneyAdded() {
        double expected = 1000 - 160 + 120;  // 960 -> Matches original test comment
        game.commissionShip("Sophie"); // Chest 840
        game.fightEncounter(2); // Win, Prize 120
        double actual = game.getWarChest();
        assertEquals("War chest incorrect after Frigate wins Skirmish", expected, actual, 0.5);
    }

     @Test
     // Frigate (Jupiter, Str 7) vs Skirmish (Enc 6, Req 8) -> Lose Money Check
    public void FridateFacingSkirmishLosesMoneyDeducted() {
        double expected = 1000 - 200 - 45; // 755 -> Matches original test comment
        game.commissionShip("Jupiter"); // Chest 800
        game.fightEncounter(6); // Lose, Prize 45
        double actual = game.getWarChest();
        assertEquals("War chest incorrect after Frigate loses Skirmish", expected, actual, 0.5);
    }


    // --- Extra Tests ---

    @Test
    // --- Extra Test ---
    // Verifies that a Sloop cannot fight a Blockade encounter (Enc 3), resulting in loss.
    public void sloopCannotFightBlockade() {
        // Setup: Commission only a Sloop (Arrow, Fee 150)
        game.commissionShip("Arrow");
        double initialChest = game.getWarChest(); // Should be 1000 - 150 = 850
        int encounterPrize = 150; // Prize/Penalty for Encounter 3 (Blockade Brest)

        // Action: Try to fight Blockade Brest (Encounter 3)
        String result = game.fightEncounter(3);

        // Assertions:
        // 1. Result message should indicate no ship available
        assertTrue("Result message should indicate no ship available", result.contains("no ship available"));
        // 2. War chest should decrease by the encounter prize
        double expectedChest = initialChest - encounterPrize; // 850 - 150 = 700
        assertEquals("War chest should decrease by prize", expectedChest, game.getWarChest(), 0.5);
        // 3. Arrow should still be active (not sunk or resting because it never fought)
        assertTrue("Arrow should remain active", game.isInSquadron("Arrow"));
    }

    @Test
    // --- Extra Test ---
    // Verifies that a ManOWar cannot fight a Skirmish encounter (Enc 2), resulting in loss.
    public void manowarCannotFightSkirmish() {
        // Setup: Commission only a ManOWar (Victory, Fee 500)
        game.commissionShip("Victory");
        double initialChest = game.getWarChest(); // Should be 1000 - 500 = 500
        int encounterPrize = 120; // Prize/Penalty for Encounter 2 (Skirmish Belle Isle)

        // Action: Try to fight Skirmish Belle Isle (Encounter 2)
        String result = game.fightEncounter(2);

        // Assertions:
        // 1. Result message should indicate no ship available
        assertTrue("Result message should indicate no ship available", result.contains("no ship available"));
        // 2. War chest should decrease by the encounter prize
        double expectedChest = initialChest - encounterPrize; // 500 - 120 = 380
        assertEquals("War chest should decrease by prize", expectedChest, game.getWarChest(), 0.5);
        // 3. Victory should still be active (not sunk or resting because it never fought)
        assertTrue("Victory should remain active", game.isInSquadron("Victory"));
    }

} // End of T5FightEncounterTest class