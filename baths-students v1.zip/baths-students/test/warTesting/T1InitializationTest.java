/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package warTesting;

import wars.*;
import java.util.*;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Tests related to the initial state of the game.
 * @author comqaam (Original author), Dinojan Baskaran (Additions)
 */
public class T1InitializationTest {
    BATHS game;

    public T1InitializationTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
        // Create a fresh game instance before each test method
        game = new SeaBattles("Olek");
    }

    @After
    public void tearDown() {
    }

    // Helper method to check if a String contains all substrings from an array
    private boolean containsText(String text, String[] s) {
        boolean check = true;
        for(int i=0; i < s.length; i++) {
            // Ensure text is not null before calling contains
            if (text == null) return false;
            check = check && text.contains(s[i]);
        }
        return check;
    }

    @Test
    // Checks if the initial toString() output contains expected elements
    public void gameCorrectlyInitialised() {
        String result = game.toString();
        // Expected substrings based on constructor and initial state
        String[] xx = {"Olek","1000", "Is OK", "No ships"}; // Uses "Is OK" based on previous fix
        boolean actual = containsText(result,xx );
        assertTrue("Initial toString() should contain admiral, chest, status, and no ships message", actual);
    }

    @Test
    // Checks if the initial war chest value is correct
    public void treasuryTest() {
        double expected = 1000;
        double actual = game.getWarChest();
        assertEquals("Initial war chest should be 1000", expected, actual, 0.5);
    }

    @Test
    // Checks if the game starts in a non-defeated state
    public void defeatedTest() {
        boolean actual = game.isDefeated();
        assertFalse("Game should not be defeated at the start", actual);
    }

    @Test
    // Checks if all ships start outside the active squadron
    public void checkTeamEmptyAtStart() {
        boolean result = true;
        // List of all ship names from Appendix A
        List<String> ships = new ArrayList<String>(Arrays.asList("Victory","Sophie",
                 "Endeavour","Arrow", "Belerophon", "Surprise","Jupiter", "Paris", "Beast", "Athena"));

        // Verify none are initially in the active squadron
        for (String shipName : ships) {
            result = result && !game.isInSquadron(shipName);
        }
        assertTrue("No ships should be in the active squadron initially", result);
    }

    @Test
    // --- Extra Test ---
    // Checks if isDefeated returns true when war chest is negative and no ships are active.
    public void testDefeatedWhenBrokeAndNoActiveShips() {
        // Simulate losing encounters when no ships are active to reduce war chest
        // Assumes Encounter 1 prize is 300
        assertFalse("Should not be defeated initially", game.isDefeated()); // Starts at 1000
        game.fightEncounter(1); // Chest = 700, Result: "1-Encounter lost..."
        assertFalse("Should not be defeated at 700", game.isDefeated());
        assertEquals("War chest should be 700 after first loss", 700, game.getWarChest(), 0.5);

        game.fightEncounter(1); // Chest = 400
        assertFalse("Should not be defeated at 400", game.isDefeated());
        assertEquals("War chest should be 400 after second loss", 400, game.getWarChest(), 0.5);

        game.fightEncounter(1); // Chest = 100
        assertFalse("Should not be defeated at 100", game.isDefeated());
        assertEquals("War chest should be 100 after third loss", 100, game.getWarChest(), 0.5);

        game.fightEncounter(1); // Chest = -200
        assertTrue("Should be defeated at -200 with no active ships", game.isDefeated());
        assertEquals("War chest should be -200 after fourth loss", -200, game.getWarChest(), 0.5);
    }

} // End of T1InitializationTest class