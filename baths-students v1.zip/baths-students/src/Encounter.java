package wars;

import java.io.Serializable;

/**
 * Represents a single encounter or challenge within the BATHS game.
 * Stores details about the encounter's identification, type, opponent,
 * potential reward/penalty, and the difficulty (strength required).
 * Implements Serializable for game state saving/loading.
 *
 * @author Dinojan Baskaran // Or your team name
 * @version 2024-03-14 // Or current date
 */
public class Encounter implements Serializable { // Implement Serializable for Task 3.5

    // Private fields to store encounter attributes
    private int encounterNo;
    private EncounterType type; // Uses the provided EncounterType enum
    private String enemy; // Description of the opponent/location
    private int prize; // Amount gained on win / lost on loss
    private int strengthRequired; // Difficulty rating

    /**
     * Constructor for creating a new Encounter instance.
     *
     * @param encounterNo      The unique integer identifying this specific encounter.
     * @param type             The type classification of the encounter (BLOCKADE, BATTLE, SKIRMISH).
     * @param enemy            A String describing the enemy or location context (e.g., "Trafalgar", "Pirates").
     * @param prize            The integer amount representing the reward for winning or penalty for losing.
     * @param strengthRequired The integer value representing the battle strength needed to likely win this encounter.
     */
    public Encounter(int encounterNo, EncounterType type, String enemy, int prize, int strengthRequired) {
        this.encounterNo = encounterNo;
        this.type = type;
        this.enemy = enemy;
        this.prize = prize;
        this.strengthRequired = strengthRequired;
    }

    // --- Getters ---
    // Provide read-only access to the encounter's attributes.

    /**
     * Retrieves the unique identification number of the encounter.
     * @return The encounter number as an integer.
     */
    public int getEncounterNo() {
        return encounterNo;
    }

    /**
     * Retrieves the type classification of the encounter.
     * @return The EncounterType enum value (BLOCKADE, BATTLE, SKIRMISH).
     */
    public EncounterType getType() {
        return type;
    }

    /**
     * Retrieves the description of the enemy or location for the encounter.
     * @return The enemy/location description as a String.
     */
    public String getEnemy() {
        return enemy;
    }

    /**
     * Retrieves the prize amount associated with winning/losing the encounter.
     * @return The prize/penalty amount as an integer.
     */
    public int getPrize() {
        return prize;
    }

    /**
     * Retrieves the battle strength required to likely succeed in this encounter.
     * @return The required strength as an integer.
     */
    public int getStrengthRequired() {
        return strengthRequired;
    }

    // --- toString Method ---
    // Provides a standardized string representation for display.

    /**
     * Returns a formatted string summarizing the encounter's key details.
     * Includes number, type, enemy, prize, and required strength.
     * @return A human-readable string representation of the encounter object.
     */
    @Override
    public String toString() {
        // Provides a consistent format for displaying encounter information
        return "Encounter No: " + encounterNo +
               ", Type: " + type.toString() + // Use the enum's descriptive toString()
               ", Enemy: " + enemy +
               ", Prize/Penalty: " + prize +
               ", Strength Required: " + strengthRequired;
    }
}