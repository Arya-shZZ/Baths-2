package wars;

import java.io.*; // Included for completeness, though not directly used here
import java.util.*; // Needed for Scanner

/**
 * Provides a command line interface for the BATHS game.
 * Allows users to interact with the SeaBattles functionality via menu options.
 * Includes implementation for all relevant menu choices based on Tasks 3.2 and 3.5.
 *
 * @author A.A.Marczyk (Original author), Dinojan Baskaran (Updates)
 * @version 2024-03-14 // Date updated
 */
public class GameUI {
    private BATHS myBattles; // Use the interface type for flexibility
    private Scanner myIn = new Scanner(System.in);

    /**
     * Main control loop for the command line interface.
     * Creates the game instance, displays the menu, gets user input,
     * and calls the appropriate methods in the SeaBattles object.
     */
    public void doMain() {
        int choice;
        System.out.println("Enter admiral's name");
        String name = myIn.nextLine();
        // Create the game instance using the default constructor
        // To test Task 3.5 file reading, temporarily change this to:
        // myBattles = new SeaBattles(name, "encountersAM.txt");
        myBattles = new SeaBattles(name);

        choice = -1; // Initialize choice to ensure loop starts correctly
        while (choice != 0) {
            choice = getMenuItem();

            if (choice == 1) { // List Reserve Fleet
                System.out.println(myBattles.getReserveFleet());
            } else if (choice == 2) { // List Squadron
                System.out.println(myBattles.getSquadron());
            } else if (choice == 3) { // View a Ship
                System.out.println("Enter Ship name");
                // Consume the leftover newline from nextInt() in getMenuItem()
                myIn.nextLine();
                String ref = (myIn.nextLine()).trim();
                System.out.println(myBattles.getShipDetails(ref));
            } else if (choice == 4) { // Commission Ship
                System.out.println("Enter Ship name to commission:");
                myIn.nextLine(); // Consume newline
                String shipName = myIn.nextLine().trim();
                String result = myBattles.commissionShip(shipName); // Call the method
                System.out.println(result); // Print the result message
            } else if (choice == 5) { // Fight Encounter
                System.out.println("Enter Encounter number to fight:");
                // List available encounters first (optional but helpful)
                System.out.println(myBattles.getAllEncounters());

                int encounterNo = -1; // Initialize
                 // Input validation loop for encounter number
                 while(encounterNo < 1 || encounterNo > 10) { // Assuming encounters 1-10
                     System.out.print("Enter number (1-10): ");
                     while (!myIn.hasNextInt()) {
                          System.out.println("Invalid input. Please enter a number.");
                          myIn.next(); // Consume invalid input
                          System.out.print("Enter number (1-10): ");
                     }
                     encounterNo = myIn.nextInt();
                     if(encounterNo < 1 || encounterNo > 10) {
                         System.out.println("Invalid encounter number.");
                     }
                 }
                myIn.nextLine(); // Consume the leftover newline

                String result = myBattles.fightEncounter(encounterNo); // Call the method
                System.out.println(result); // Print the result message

            } else if (choice == 6) { // Restore Ship
                System.out.println("Enter Ship name to restore from resting:");
                myIn.nextLine(); // Consume newline
                String shipName = myIn.nextLine().trim();
                myBattles.restoreShip(shipName); // Call the method (void return)
                // Provide some feedback, even though restoreShip is void
                System.out.println(shipName + " restore attempted (if resting).");
            } else if (choice == 7) { // Decommission Ship
                System.out.println("Enter Ship name to decommission:");
                myIn.nextLine(); // Consume newline
                String shipName = myIn.nextLine().trim();
                boolean success = myBattles.decommissionShip(shipName); // Call the method
                if (success) {
                    System.out.println(shipName + " decommissioned successfully.");
                } else {
                    System.out.println(shipName + " could not be decommissioned (not found or not active).");
                }
            } else if (choice == 8) { // View Admiral's State
                System.out.println(myBattles.toString());
            }
            // --- Options for Task 3.5 ---
            else if (choice == 9) { // Save Game
                System.out.println("Enter filename to save game (e.g., game.sav):");
                myIn.nextLine(); // Consume the leftover newline character from getMenuItem()
                String saveFilename = myIn.nextLine().trim(); // Read filename from user
                if (!saveFilename.isEmpty()) { // Basic check if user entered something
                     myBattles.saveGame(saveFilename); // Call saveGame with the filename
                } else {
                     System.out.println("Save cancelled (no filename entered).");
                }
            } else if (choice == 10) { // Load Game
                   System.out.println("Enter filename to load game (e.g., game.sav):");
                   myIn.nextLine(); // Consume the leftover newline character from getMenuItem()
                   String loadFilename = myIn.nextLine().trim(); // Read filename from user

                   if (!loadFilename.isEmpty()) { // Basic check
                       SeaBattles loadedBattles = null; // Declare variable for loaded game
                       // Call loadGame on the existing game object
                       // Note: loadGame itself should handle file not found etc. and print errors
                       loadedBattles = myBattles.loadGame(loadFilename);

                       // Check if loading was successful before trying to use/print
                       if (loadedBattles != null) {
                           // Replace the current game state with the loaded one
                           myBattles = loadedBattles;
                           System.out.println("Game loaded successfully. Current game replaced.");
                           System.out.println(myBattles.toString()); // Show the newly loaded state
                       } else {
                           // loadGame method should have printed an error message
                           System.out.println("Failed to load game from " + loadFilename + ". Check console for errors.");
                       }
                   } else {
                       System.out.println("Load cancelled (no filename entered).");
                   }
            }
            // --- End of Task 3.5 Options ---

        } // End of while loop
        System.out.println("Thank-you");
    } // End of doMain method

    /**
     * Displays the main menu options to the user and reads their choice.
     * Ensures the choice is within the valid range (0-10).
     * Includes basic input validation.
     *
     * @return The integer representing the user's valid menu choice.
     */
    private int getMenuItem() {
        int choice = -1; // Initialize choice to an invalid value
        System.out.println("\nMain Menu");
        System.out.println("0. Quit");
        System.out.println("1. List ships in the reserve fleet");
        System.out.println("2. List ships in admirals squadron");
        System.out.println("3. View a ship");
        System.out.println("4. Commission a ship into admiral's squadron");
        System.out.println("5. Fight an encounter");
        System.out.println("6. Restore a ship");
        System.out.println("7. Decommission a ship");
        System.out.println("8. View admiral's state");
        System.out.println("9. Save this game");
        System.out.println("10. Restore a game");

        // Loop until a valid choice is entered
        while (choice < 0 || choice > 10) {
            System.out.println("Enter the number of your choice");
            // Input validation: Check if the next input is actually an integer
            while (!myIn.hasNextInt()) {
                 System.out.println("Invalid input. Please enter a number between 0 and 10.");
                 myIn.next(); // Consume the invalid non-integer input
            }
            choice = myIn.nextInt(); // Read the valid integer
            // Check if the integer is within the allowed range
            if (choice < 0 || choice > 10) {
                System.out.println("Invalid choice. Please enter a number between 0 and 10.");
            }
        }
         // It's generally safer to consume the newline AFTER reading the int,
         // but individual handlers (like option 3, 4, 6, 7, 9, 10) are doing it before reading the next line.
         // myIn.nextLine(); // Consume newline here - REMOVED, handled in specific options
        return choice;
    }

    /**
     * The main method to start the GameUI application.
     * Creates an instance of GameUI and calls its doMain method.
     *
     * @param args Command line arguments (not used).
     */
    public static void main(String[] args) {
        GameUI xxx = new GameUI();
        xxx.doMain();
    }
} // End of GameUI class