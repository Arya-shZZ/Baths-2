package wars;

import java.util.*;
import java.io.*;
// Imports needed for Serialization, File Reading, and other parts
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.ClassNotFoundException;

import wars.Ship;
import wars.Encounter;
import wars.ShipState;
import wars.EncounterType;


/**
 * Implements the BATHS interface, managing the state and logic of the
 * Battles and High Seas game. Handles ships, encounters, the war chest,
 * and player actions like commissioning, fighting, etc.
 * Includes Javadoc documentation as per Task 3.3.
 * Includes fixes based on JUnit test results.
 * Includes Persistence methods (Serialization and Text File Reading) for Task 3.5.
 *
 * @author Dinojan Baskaran // Or your team name
 * @version 2024-03-14 // Or current date
 */
public class SeaBattles implements BATHS { // BATHS already extends Serializable
    // Instance variables to store game state
    private String admiral;
    private double warChest;

    // Collections to store all ships and encounters, keyed for easy lookup
    private HashMap<String, Ship> allShips;
    private HashMap<Integer, Encounter> allEncounters;


    /**
     * Constructor: Initializes the game state for a new game using default setup.
     * Sets up the admiral's name, initial war chest, initializes ship and
     * encounter collections, and loads initial data using setup methods.
     *
     * @param adm The name of the admiral playing the game.
     */
    public SeaBattles(String adm) {
        this.admiral = adm;
        this.warChest = 1000; // Sensible starting money

        // Initialize the collections before loading data
        this.allShips = new HashMap<>();
        this.allEncounters = new HashMap<>();

        // Load initial game data from Appendix A (or other source)
        setupShips();       // Load hardcoded ships
        setupEncounters();  // Load hardcoded encounters
    }

    /**
     * Constructor for Task 3.5: Initializes the game state using ship setup
     * and loading encounters from a specified text file.
     *
     * @param admir The name of the admiral playing the game.
     * @param filename The name of the text file containing encounter data.
     */
    public SeaBattles(String admir, String filename) {
        this.admiral = admir;
        this.warChest = 1000; // Sensible starting money

        // Initialize the collections before loading data
        this.allShips = new HashMap<>();
        this.allEncounters = new HashMap<>();

        // Load initial game data
        setupShips();           // Load hardcoded ships
        readEncounters(filename); // <<< Load encounters from text file
        // setupEncounters();    // <<< DO NOT CALL THIS ONE HERE
    }


    // --- Public methods implementing BATHS interface ---

    /**
     * Returns a String representation of the current overall game state.
     * Includes admiral details, war chest, defeat status, and squadron summary.
     *
     * @return A multi-line String summarizing the game state.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("****** Game State ******\n");
        sb.append("Admiral: ").append(this.admiral).append("\n");
        sb.append("War Chest: ").append(String.format("%.2f", this.warChest)).append("\n"); // Format currency
        sb.append("Status: ").append(isDefeated() ? "DEFEATED" : "Is OK").append("\n"); // Use status string
        sb.append("\n--- Squadron ---\n");
        String squadron = getSquadron(); // Get active ships list
        // Check if the returned string indicates no ships were found
        sb.append(squadron.equals("No ships commissioned.") ? "No ships in squadron.\n" : squadron);
        // Note: Does not explicitly list RESTING ships here, only ACTIVE via getSquadron()

        sb.append("************************\n");
        return sb.toString();
    }


    /**
     * Checks if the player is defeated.
     * Defeat occurs if the War Chest is zero or less AND there are no
     * ACTIVE ships left in the squadron.
     *
     * @return true if the player is defeated, false otherwise.
     */
    @Override
    public boolean isDefeated() {
        if (this.warChest > 0) {
            return false; // Not defeated if there's money
        }
        // Money <= 0, check for any active ships
        for (Ship ship : allShips.values()) {
            if (ship.getState() == ShipState.ACTIVE) {
                return false; // Found an active ship
            }
        }
        return true; // Money <= 0 and no active ships found
    }

    /**
     * Returns the current amount of money in the War Chest.
     *
     * @return The amount in the War Chest as a double.
     */
    @Override
    public double getWarChest() {
        return this.warChest;
    }


    /**
     * Returns a String listing all ships currently in the reserve fleet
     * (state = RESERVE).
     *
     * @return A multi-line String listing reserve ships, or a message if none exist.
     */
    @Override
    public String getReserveFleet() {
        StringBuilder sb = new StringBuilder("=== Reserve Fleet ===\n");
        boolean found = false;
        for (Ship ship : allShips.values()) {
            if (ship.getState() == ShipState.RESERVE) {
                sb.append(ship.toString()).append("\n");
                found = true;
            }
        }
        return found ? sb.toString() : "No ships in reserve fleet.";
    }

    /**
     * Returns a String listing all ships currently active in the admiral's squadron
     * (state = ACTIVE).
     *
     * @return A multi-line String listing active ships, or "No ships commissioned." if none exist.
     */
    @Override
    public String getSquadron() {
        StringBuilder sb = new StringBuilder("=== Admiral's Squadron ===\n");
        boolean found = false;
        for (Ship ship : allShips.values()) {
            if (ship.getState() == ShipState.ACTIVE) {
                sb.append(ship.toString()).append("\n");
                found = true;
            }
        }
        return found ? sb.toString() : "No ships commissioned.";
    }

    /**
     * Returns a String listing all ships that have been sunk
     * (state = SUNK).
     *
     * @return A multi-line String listing sunk ships, or "No ships sunk yet." if none exist.
     */
    @Override
    public String getSunkShips() {
        StringBuilder sb = new StringBuilder("=== Sunken Ships ===\n");
        boolean found = false;
        for (Ship ship : allShips.values()) {
            if (ship.getState() == ShipState.SUNK) {
                sb.append(ship.toString()).append("\n");
                found = true;
            }
        }
        return found ? sb.toString() : "No ships sunk yet.";
    }

    /**
     * Returns a String listing all ships currently managed by the game,
     * regardless of their state, including their state information.
     *
     * @return A multi-line String listing all ships.
     */
    @Override
    public String getAllShips() {
        StringBuilder sb = new StringBuilder("=== All Ships ===\n");
        if (allShips.isEmpty()) {
            return "No ships in the game.";
        }
        for (Ship ship : allShips.values()) {
            sb.append(ship.toString()).append("\n");
        }
        return sb.toString();
    }


    /**
     * Retrieves the details of a specific ship by its unique name.
     *
     * @param nme The name of the ship to retrieve details for.
     * @return A String containing the ship's details (from its toString method),
     *         or "\nNo such ship" if no ship with that name is found.
     */
    @Override
    public String getShipDetails(String nme) {
        Ship foundShip = allShips.get(nme);
        return (foundShip != null) ? foundShip.toString() : "\nNo such ship";
    }


    /**
     * Attempts to commission a ship into the admiral's active squadron.
     * Checks for existence, availability (must be in reserve), and sufficient funds.
     * If successful, deducts the fee from the war chest and sets the ship state to ACTIVE.
     *
     * @param nme The unique name of the ship to commission.
     * @return A String message indicating the outcome: "Ship commissioned",
     *         "Not found", "Not available", or "Not enough money".
     */
    @Override
    public String commissionShip(String nme) {
        Ship shipToCommission = allShips.get(nme);
        if (shipToCommission == null) { return "Not found"; }
        if (shipToCommission.getState() != ShipState.RESERVE) { return "Not available"; }
        if (this.warChest < shipToCommission.getCommissionFee()) { return "Not enough money"; }

        this.warChest -= shipToCommission.getCommissionFee();
        shipToCommission.setState(ShipState.ACTIVE);
        return "Ship commissioned";
    }


    /**
     * Checks if a ship with the specified name is currently active in the squadron.
     *
     * @param nme The name of the ship to check.
     * @return true if the ship exists and its state is ACTIVE, false otherwise.
     */
    @Override
    public boolean isInSquadron(String nme) {
        Ship ship = allShips.get(nme);
        return (ship != null && ship.getState() == ShipState.ACTIVE);
    }


    /**
     * Moves an ACTIVE ship from the squadron back to the reserve fleet.
     * Adds the ship's commission fee back to the war chest (based on T6 tests).
     *
     * @param nme The name of the ship to decommission.
     * @return true if the ship was successfully decommissioned (found and was active),
     *         false otherwise.
     */
    @Override
    public boolean decommissionShip(String nme) {
        Ship shipToDecommission = allShips.get(nme);
        if (shipToDecommission != null && shipToDecommission.getState() == ShipState.ACTIVE) {
            shipToDecommission.setState(ShipState.RESERVE);
            this.warChest += shipToDecommission.getCommissionFee(); // Refund restored
            return true;
        }
        return false;
    }


    /**
     * Restores a RESTING ship back to the ACTIVE state in the squadron.
     * Does nothing if the ship is not found or not in the RESTING state.
     *
     * @param nme The name of the ship to restore.
     */
    @Override
    public void restoreShip(String nme) {
        Ship shipToRestore = allShips.get(nme);
        if (shipToRestore != null && shipToRestore.getState() == ShipState.RESTING) {
            shipToRestore.setState(ShipState.ACTIVE);
        }
    }


    /**
     * Checks if an encounter with the specified number exists in the game.
     *
     * @param num The number of the encounter to check.
     * @return true if an encounter with this number exists, false otherwise.
     */
     @Override
     public boolean isEncounter(int num) {
         return allEncounters.containsKey(num);
     }


    /**
     * Simulates fighting a specified encounter.
     * Finds the encounter, finds a suitable active ship (using updated logic),
     * determines the outcome based on strength comparison, updates ship state (RESTING or SUNK),
     * updates the war chest (adds prize or deducts penalty), and checks for defeat.
     *
     * @param encNo The number of the encounter to fight.
     * @return A String describing the outcome of the encounter, including the
     *         final war chest amount and defeat status if applicable. Returns
     *         "-1 No such encounter" if the encounter number is invalid.
     */
    @Override
    public String fightEncounter(int encNo) {
        Encounter encounter = allEncounters.get(encNo);
        if (encounter == null) { return "-1 No such encounter"; }

        Ship fightingShip = findSuitableShip(encounter); // Use helper method

        if (fightingShip == null) {
            // No suitable ship found
            this.warChest -= encounter.getPrize();
            String result = "1-Encounter lost as no ship available.";
            if (isDefeated()) { result += " You have been defeated"; }
            return result + "\nWar Chest: " + String.format("%.2f", this.warChest);
        }

        // Ship found, resolve combat
        String resultMessage;
        if (fightingShip.getBattleStrength() >= encounter.getStrengthRequired()) {
            // WIN
            this.warChest += encounter.getPrize();
            fightingShip.setState(ShipState.RESTING);
            resultMessage = "0-Encounter won by " + fightingShip.getName() + ".";
        } else {
            // LOSS
            this.warChest -= encounter.getPrize();
            fightingShip.setState(ShipState.SUNK);
            resultMessage = "2-Encounter lost on battle skill and " + fightingShip.getName() + " sunk.";
            if (isDefeated()) { resultMessage += " You have been defeated"; }
        }
        return resultMessage + "\nWar Chest: " + String.format("%.2f", this.warChest);
    }


    /**
     * Retrieves the details of a specific encounter by its unique number.
     *
     * @param num The number of the encounter to retrieve details for.
     * @return A String containing the encounter's details (from its toString method),
     *         or "\nNo such encounter" if no encounter with that number is found.
     */
    @Override
    public String getEncounter(int num) {
        Encounter foundEncounter = allEncounters.get(num);
        return (foundEncounter != null) ? foundEncounter.toString() : "\nNo such encounter";
    }


    /**
     * Returns a String listing all encounters currently available in the game.
     *
     * @return A multi-line String listing all encounters.
     */
    @Override
    public String getAllEncounters() {
        StringBuilder sb = new StringBuilder("=== All Encounters ===\n");
        if (allEncounters.isEmpty()) { return "No encounters available."; }
        for (Encounter encounter : allEncounters.values()) {
            sb.append(encounter.toString()).append("\n");
        }
        return sb.toString();
    }

    // --- Methods for Task 3.5 (Persistence) ---

    /**
     * Writes the entire current game state (this SeaBattles object) to the
     * specified file using object serialization.
     * Handles potential IOExceptions.
     * NOTE: Uncomment @Override if uncommenting in BATHS interface.
     *
     * @param fname The name of the file to save the game state to.
     */
    // @Override
    public void saveGame(String fname) {
        ObjectOutputStream output = null; // Declare outside try block
        try {
            FileOutputStream fileOut = new FileOutputStream(fname);
            output = new ObjectOutputStream(fileOut);
            output.writeObject(this); // Write the current object
            System.out.println("Game saved successfully to " + fname); // User feedback
        } catch (IOException e) {
            System.err.println("Error saving game to " + fname + ": " + e.getMessage());
        } finally {
            try {
                if (output != null) { output.close(); } // Always close stream
            } catch (IOException e) {
                System.err.println("Error closing save file stream: " + e.getMessage());
            }
        }
    }

    /**
     * Reads a complete SeaBattles game state from the specified file
     * using object deserialization.
     * Handles potential IOExceptions and ClassNotFoundExceptions.
     * NOTE: Uncomment @Override if uncommenting in BATHS interface.
     *
     * @param fname The name of the file to load the game state from.
     * @return The loaded SeaBattles object, or null if loading fails.
     */
    // @Override
    public SeaBattles loadGame(String fname) {
        ObjectInputStream input = null; // Declare outside try block
        SeaBattles loadedGame = null;
        try {
            FileInputStream fileIn = new FileInputStream(fname);
            input = new ObjectInputStream(fileIn);
            loadedGame = (SeaBattles) input.readObject(); // Read and cast object
            System.out.println("Game loaded successfully from " + fname); // User feedback
        } catch (IOException e) {
            System.err.println("Error loading game from " + fname + ": " + e.getMessage());
            loadedGame = null;
        } catch (ClassNotFoundException e) {
            System.err.println("Error loading game: Class not found. " + e.getMessage());
            loadedGame = null;
        } finally {
            try {
                if (input != null) { input.close(); } // Always close stream
            } catch (IOException e) {
                System.err.println("Error closing load file stream: " + e.getMessage());
            }
        }
        return loadedGame; // Return loaded object or null
    }

    /**
     * Reads encounter data from a specified text file (e.g., encountersAM.txt)
     * and populates the allEncounters map. Called by the second constructor.
     * Assumes comma-separated format: Type,Enemy,Strength,Prize
     * Assigns encounter numbers sequentially starting from 1.
     *
     * @param filename The name of the text file containing encounter data.
     */
    public void readEncounters(String filename) {
        // Ensure map is clear if called standalone, though constructor usually handles this
        // this.allEncounters.clear();

        String line = "";
        int encounterNumber = 1; // Start numbering encounters from 1

        // Use try-with-resources for automatic closing of reader
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            System.out.println("Reading encounters from: " + filename); // Feedback

            while ((line = reader.readLine()) != null) {
                line = line.trim(); // Remove leading/trailing whitespace
                if (line.isEmpty() || line.startsWith("//") || line.startsWith("#")) {
                    continue; // Skip empty lines and comments
                }

                String[] parts = line.split(","); // Split line by comma

                if (parts.length == 4) { // Expecting 4 parts
                    try {
                        // Trim whitespace from individual parts
                        String typeStr = parts[0].trim();
                        String enemyStr = parts[1].trim();
                        String strengthStr = parts[2].trim();
                        String prizeStr = parts[3].trim();

                        // Convert type string to EncounterType enum (case-insensitive)
                        EncounterType type = EncounterType.valueOf(typeStr.toUpperCase());

                        // Parse integers
                        int strengthRequired = Integer.parseInt(strengthStr);
                        int prize = Integer.parseInt(prizeStr);

                        // Create and store the encounter
                        Encounter encounter = new Encounter(encounterNumber, type, enemyStr, prize, strengthRequired);
                        this.allEncounters.put(encounterNumber, encounter);

                        encounterNumber++; // Increment for the next valid line

                    } catch (NumberFormatException e) {
                        System.err.println("Skipping invalid line in " + filename + " (bad number format): [" + line + "] - " + e.getMessage());
                    } catch (IllegalArgumentException e) {
                        System.err.println("Skipping invalid line in " + filename + " (bad encounter type): [" + line + "] - " + e.getMessage());
                    } catch (Exception e) { // Catch any other unexpected errors during parsing
                         System.err.println("Skipping invalid line in " + filename + " (unexpected error): [" + line + "] - " + e.getMessage());
                    }
                } else {
                    System.err.println("Skipping invalid line in " + filename + " (wrong number of parts): [" + line + "]");
                }
            }
            System.out.println("Finished reading encounters. Loaded " + (this.allEncounters.size()) + " encounters.");

        } catch (FileNotFoundException e) {
            System.err.println("Error reading encounters: File not found - " + filename);
            // Fallback: Load hardcoded encounters if file not found?
            System.out.println("Falling back to default encounters setup.");
            setupEncounters();
        } catch (IOException e) {
            System.err.println("Error reading encounters file: " + e.getMessage());
            // Fallback?
             System.out.println("Falling back to default encounters setup due to IO Error.");
            setupEncounters();
        }
    }


    //****************** private helper methods below *******************

    /**
     * Sets up the initial fleet of ships based on Appendix A data, including all details.
     * Called by the constructor(s). Populates the allShips HashMap.
     */
    private void setupShips() {
        // Ship(Name, Type, Fee, Str, Capt, Decks, Marines, Cannons, Doc/Pin)
        Ship victory = new Ship("Victory", "ManOWar", 500, 3, "Alan Aikin", 3, 30, 0, false); allShips.put(victory.getName(), victory);
        Ship sophie = new Ship("Sophie", "Frigate", 160, 8, "Ben Baggins", 0, 0, 16, true); allShips.put(sophie.getName(), sophie);
        Ship endeavour = new Ship("Endeavour", "ManOWar", 300, 4, "Col Cannon", 2, 20, 0, false); allShips.put(endeavour.getName(), endeavour);
        Ship arrow = new Ship("Arrow", "Sloop", 150, 5, "Dan Dare", 0, 0, 0, true); allShips.put(arrow.getName(), arrow);
        Ship belerophon = new Ship("Belerophon", "ManOWar", 500, 8, "Ed Evans", 3, 50, 0, false); allShips.put(belerophon.getName(), belerophon);
        Ship surprise = new Ship("Surprise", "Frigate", 100, 6, "Fred Fox", 0, 0, 10, false); allShips.put(surprise.getName(), surprise);
        Ship jupiter = new Ship("Jupiter", "Frigate", 200, 7, "Gil Gamage", 0, 0, 20, false); allShips.put(jupiter.getName(), jupiter);
        Ship paris = new Ship("Paris", "Sloop", 200, 5, "Hal Henry", 0, 0, 0, true); allShips.put(paris.getName(), paris);
        Ship beast = new Ship("Beast", "Sloop", 400, 5, "Ian Idle", 0, 0, 0, false); allShips.put(beast.getName(), beast);
        Ship athena = new Ship("Athena", "Sloop", 100, 5, "John Jones", 0, 0, 0, true); allShips.put(athena.getName(), athena);
    }

    /**
     * Sets up the initial list of encounters based on Appendix A data (hardcoded).
     * Called by the default constructor or as fallback. Populates the allEncounters HashMap.
     */
    private void setupEncounters() {
        // Ensure map is clear before adding hardcoded encounters
        this.allEncounters.clear();
        Encounter enc1 = new Encounter(1, EncounterType.BATTLE, "Trafalgar", 300, 3); allEncounters.put(enc1.getEncounterNo(), enc1);
        Encounter enc2 = new Encounter(2, EncounterType.SKIRMISH, "Belle Isle", 120, 3); allEncounters.put(enc2.getEncounterNo(), enc2);
        Encounter enc3 = new Encounter(3, EncounterType.BLOCKADE, "Brest", 150, 3); allEncounters.put(enc3.getEncounterNo(), enc3);
        Encounter enc4 = new Encounter(4, EncounterType.BATTLE, "St Malo", 200, 9); allEncounters.put(enc4.getEncounterNo(), enc4);
        Encounter enc5 = new Encounter(5, EncounterType.BLOCKADE, "Dieppe", 90, 7); allEncounters.put(enc5.getEncounterNo(), enc5);
        Encounter enc6 = new Encounter(6, EncounterType.SKIRMISH, "Jersey", 45, 8); allEncounters.put(enc6.getEncounterNo(), enc6);
        Encounter enc7 = new Encounter(7, EncounterType.BLOCKADE, "Nantes", 130, 6); allEncounters.put(enc7.getEncounterNo(), enc7);
        Encounter enc8 = new Encounter(8, EncounterType.BATTLE, "Finisterre", 100, 4); allEncounters.put(enc8.getEncounterNo(), enc8);
        Encounter enc9 = new Encounter(9, EncounterType.SKIRMISH, "Biscay", 200, 5); allEncounters.put(enc9.getEncounterNo(), enc9);
        Encounter enc10 = new Encounter(10, EncounterType.BATTLE, "Cadiz", 250, 1); allEncounters.put(enc10.getEncounterNo(), enc10);
        System.out.println("Loaded 10 default encounters."); // Feedback for fallback
    }

    /**
     * Finds the first ACTIVE ship in the squadron that is suitable
     * for the given encounter type based on Appendix A rules and test results.
     * This is a helper method for fightEncounter.
     *
     * @param encounter The encounter to find a suitable ship for.
     * @return A suitable, active Ship object, or null if none is found.
     */
    private Ship findSuitableShip(Encounter encounter) {
        EncounterType type = encounter.getType();
        for (Ship ship : allShips.values()) {
            if (ship.getState() == ShipState.ACTIVE) {
                String shipType = ship.getType();
                boolean suitable = false;

                if (shipType.equals("ManOWar")) {
                    // ManOWar can fight Battles and Blockades
                    if (type == EncounterType.BATTLE || type == EncounterType.BLOCKADE) {
                        suitable = true;
                    }
                } else if (shipType.equals("Frigate")) {
                    // Frigate can fight Battles and Skirmishes always.
                    // Can fight Blockade ONLY IF it has a pinnace (hasDoctorOrPinnace is true).
                     if (type == EncounterType.BATTLE || type == EncounterType.SKIRMISH) {
                        suitable = true;
                     } else if (type == EncounterType.BLOCKADE && ship.isHasDoctorOrPinnace()) { // Corrected logic
                        suitable = true;
                     }
                } else if (shipType.equals("Sloop")) {
                    // Sloop can fight Battles and Skirmishes
                    if (type == EncounterType.BATTLE || type == EncounterType.SKIRMISH) {
                        suitable = true;
                    }
                }

                if (suitable) {
                    return ship; // Found first suitable ship
                }
            }
        }
        return null; // No suitable active ship found
    }

} // End of SeaBattles class