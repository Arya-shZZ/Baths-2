package wars;

import java.io.Serializable;

/**
 * Represents a single ship in the BATHS game.
 * Stores information about the ship's identity, capabilities, cost, status,
 * and additional details from Appendix A like captain and equipment.
 * Implements Serializable to allow game state saving/loading.
 *
 * @author Dinojan Baskaran // Or your team name
 * @version 2024-03-14 // Or current date
 */
public class Ship implements Serializable { // Implement Serializable for Task 3.5

    // --- Core Fields ---
    private String name;
    private String type;
    private int commissionFee;
    private int battleStrength;
    private ShipState state; // Uses the provided ShipState enum

    // --- Added Fields for Appendix A Details ---
    private String captain;
    private int decks;
    private int marines;
    private int cannons;
    private boolean hasDoctorOrPinnace;

    /**
     * Constructor for creating a new Ship instance including all Appendix A details.
     * Ships are initialized in the RESERVE state upon creation.
     *
     * @param name               The unique name identifier for the ship.
     * @param type               The classification of the ship.
     * @param commissionFee      The cost required to activate the ship.
     * @param battleStrength     The ship's combat power rating.
     * @param captain            The name of the ship's captain.
     * @param decks              The number of decks (0 if not applicable).
     * @param marines            The number of marines (0 if not applicable).
     * @param cannons            The number of cannons (0 if not applicable).
     * @param hasDoctorOrPinnace True if the ship has a doctor (Sloop/Frigate) or pinnace (Frigate), false otherwise.
     */
    public Ship(String name, String type, int commissionFee, int battleStrength,
                String captain, int decks, int marines, int cannons, boolean hasDoctorOrPinnace) { // Added parameters

        // Core assignments
        this.name = name;
        this.type = type;
        this.commissionFee = commissionFee;
        this.battleStrength = battleStrength;
        this.state = ShipState.RESERVE; // All ships start in the reserve fleet by default

        // New assignments for extra details
        this.captain = captain;
        this.decks = decks;
        this.marines = marines;
        this.cannons = cannons;
        this.hasDoctorOrPinnace = hasDoctorOrPinnace;
    }

    // --- Getters for Core Fields ---

    /** @return The ship's unique name as a String. */
    public String getName() { return name; }
    /** @return The ship's type as a String (e.g., "ManOWar", "Frigate"). */
    public String getType() { return type; }
    /** @return The commission fee as an integer. */
    public int getCommissionFee() { return commissionFee; }
    /** @return The battle strength as an integer. */
    public int getBattleStrength() { return battleStrength; }
    /** @return The current ShipState enum value (RESERVE, ACTIVE, RESTING, SUNK). */
    public ShipState getState() { return state; }

    // --- Getters for Added Fields ---

    /** @return The captain's name as a String. */
    public String getCaptain() { return captain; }
    /** @return The number of decks as an integer. */
    public int getDecks() { return decks; }
    /** @return The number of marines as an integer. */
    public int getMarines() { return marines; }
    /** @return The number of cannons as an integer. */
    public int getCannons() { return cannons; }
    /** @return true if the ship has a doctor or pinnace, false otherwise. */
    public boolean isHasDoctorOrPinnace() { return hasDoctorOrPinnace; } // Use "is" prefix for boolean getters

    // --- Setters ---

    /**
     * Updates the current operational state of the ship.
     * @param state The new ShipState enum value to set for the ship.
     */
    public void setState(ShipState state) {
        this.state = state;
    }

    // --- toString Method ---

    /**
     * Returns a formatted string summarizing the ship's key details, including added Appendix A info.
     * NOTE: The exact format might need adjustment to pass specific tests if they are very picky.
     * @return A human-readable string representation of the ship object.
     */
    @Override
    public String toString() {
        // Attempt to include all details. Tests might expect a slightly different format.
        return "Name: " + name + ", Captain: " + captain + ", Type: " + type +
               ", Fee: " + commissionFee + ", Strength: " + battleStrength +
               ", Decks: " + decks + ", Marines: " + marines + ", Cannons: " + cannons +
               ", Doctor/Pinnace: " + hasDoctorOrPinnace + ", State:" + state.toString();
    }
}